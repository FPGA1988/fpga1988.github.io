# My Resume

[html.love](http://html.love)

<a target='_blank' rel='nofollow' href='https://app.codesponsor.io/link/ucdjQF7wcNNiWY9mCEpAeGLz/DIYgod/Resume'>
  <img alt='Sponsor' width='888' height='68' src='https://app.codesponsor.io/embed/ucdjQF7wcNNiWY9mCEpAeGLz/DIYgod/Resume.svg' />
</a>

## Introduction

风格参考 @Ovilia @joyeecheung @lishengzxc

## Usage

1. Star 本项目
1. Clone 到本地
1. 在 `index.html` 和 `print.html` 文件中填写你的信息
1. 生成PDF（以 OS X 操作系统 Chrome 浏览器为例）：打开`文件->打印`，设置布局为纵向，纸张尺寸为A3，边距无，背景图片选项打钩，保存；压缩PDF，推荐在线压缩工具[smallpdf](http://smallpdf.com/cn/compress-pdf)；将压缩过的PDF文件放在根目录内
1. 部署上线
1. Enjoy it!

## Development

```
$ npm install
$ npm install -g gulp
$ gulp
```

## LICENSE

MIT © [DIYgod](http://github.com/DIYgod)